package com.anotherexampleforabstractdp;

public  interface newfurniture {
	public abstract chair getchair(String chairtype);

	public abstract sofa getsofa(String sofatype);
	
	/* This Abstract CLass may Returns the type of the product that it what type of chair I need it may be
	 * Vicorian,Modern,....
	 */

}
