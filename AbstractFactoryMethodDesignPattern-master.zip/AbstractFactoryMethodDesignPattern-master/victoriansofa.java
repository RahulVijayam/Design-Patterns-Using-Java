package com.anotherexampleforabstractdp;

public class victoriansofa implements sofa{
	public String getsofadetails()
	{
		return "Thanks For Shopping a SOFA\nModalType:Victorian\n Modal Number:#3494\nprice:999/- per chair";
	}

}
