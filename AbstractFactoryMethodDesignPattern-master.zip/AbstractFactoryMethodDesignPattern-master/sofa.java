package com.anotherexampleforabstractdp;

public interface sofa {
	public String getsofadetails();
}
