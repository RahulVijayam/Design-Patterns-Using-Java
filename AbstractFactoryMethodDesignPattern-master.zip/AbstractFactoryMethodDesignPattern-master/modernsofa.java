package com.anotherexampleforabstractdp;

public class modernsofa implements sofa {
	public String getsofadetails()
	{
		return "Thanks For Shopping a SOFA\nModalType:Modern\n Modal Number:#3494\nprice:2999/- per chair";
	}

}
