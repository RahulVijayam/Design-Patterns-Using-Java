package com.anotherexampleforabstractdp;

public interface chair {
	public String getchairdetails();

}
