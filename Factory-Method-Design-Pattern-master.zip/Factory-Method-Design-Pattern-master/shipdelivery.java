package com.factorydesignpatern;

public class shipdelivery implements deliverymode
{
	public void delivery()
	{
		System.out.println("I Can Deliver the Product by using Ship in the SEA");
	}

}
