package com.factorydesignpatern;

public interface deliverymode
{
	void delivery();	
}

