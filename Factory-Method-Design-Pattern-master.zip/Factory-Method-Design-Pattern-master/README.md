# Factory-Method-Design-Pattern
#Imagine You are creating an E-commerce Management Application like Amazon, Flipkart..., Initial Version of your App Handles Delivery of a product by only Road Transportation. So Most of your Code May Surrounded up to the Truck Class.
Suppose a few months later your Application was getting more orders from the sea and Air transportation then definitely you will be adding these transportation methods to your application.
Generally, we think that Adding New Transportation Methods is nothing but the addition of new class to the application but it is not that simple because entire code is surrounded with Truck Class and we need to change the codebase repeatedly for every new transportation method, This my affect Performance of the Application...

It Seems Difficult to handle these types of situations, So In this Scenario, the Factory Method design pattern will Plays a key role to tackle this problem
