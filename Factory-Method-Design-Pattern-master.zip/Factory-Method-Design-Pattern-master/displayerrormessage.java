package com.factorydesignpatern;

public class displayerrormessage  implements deliverymode {
	
	public void delivery()
	{
		System.out.println("You Selected An Invalid Shipping Mode ");
	}
	
}
