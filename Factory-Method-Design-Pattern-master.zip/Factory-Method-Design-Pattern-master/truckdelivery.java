package com.factorydesignpatern;

public class truckdelivery implements deliverymode
{

	public void delivery()
	{
		System.out.println("I Can Delivery the Product by using Truck/Lorry in the Road");
	}
}
